

import time
import machine
from machine import Pin

in_button  = Pin(23, Pin.IN, Pin.PULL_UP)
out_button = Pin(22, Pin.IN, Pin.PULL_UP)

led_pins = [21, 19, 18, 5, 17, 16, 4, 15]
leds = [Pin(pin, Pin.OUT) for pin in led_pins]

car_count = 0

print("\nCar counter\n")

def update_leds(count):
  for i in range(8):
    if i < count:
      leds[i].value(1)
    else:
      leds[i].value(0)

while True:

  if in_button.value() == 0:
    if car_count < 8:
      car_count += 1
      update_leds(car_count)
      print ("Car IN,  count: ", car_count)
    else:
      print("Lot full")
    time.sleep(.5)

  if out_button.value() == 0:
    if car_count > 0:
      car_count -= 1
      update_leds(car_count)
      print ("Car OUT, count: ", car_count)
    else:
      print("Lot empty")
    time.sleep(.5)
